Goed Dag!
	My name is Benjamin Todd Troelstra and I am pretty skillful in the 'basic programing' sector of TI83+ programing (I wouldn't rank myself because I really don't know if I know everything that there is to now about BASIC).  I made these programs sometime around the beginning of the school year (Sept.-Oct. 2001), I guess I got bored in math class & my mind started wandering and then it just became a habit/project motivated by self-interest in BASIC 83+ programing and my not being challenged enough in school.
	Skipping of that llloooonggg tangent, I have provided some  pictures w/ this. (warning tangent:) I did not submit these programs earlier because......I really couldn't find any (linear) time (Universal time is preceived by the human mind/brain to be infinite) my  mind works on a 180 hour schedual. If you didn't allready find out these are 2 physics formulas programs (i'm to underminded to develop games other than "guess the number") Fizfrmls.8xp & Fizfrml2.8xp.
	IF YOU HAVE ANY QUESTIONS, COMMENTS, CONCERNS, REQUESTS, REPORTS,....ETC., E-mail me @ Q_DMC12@yahoo.com!


	Thank you for you time in reading this readme file!!

Please check-out some of my other BASIC programs: BENSAVER.8xp & SPACESIM.8xp In group file BTSAVERS.zip

						IV.XXIV.MMII